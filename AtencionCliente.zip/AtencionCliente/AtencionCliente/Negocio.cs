﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtencionCliente
{
    public class Negocio
    {
        #region Atributos
        private PuestoAtencion caja;
        private Queue<Cliente> clientes;
        private string nombre;
        #endregion

        #region Propiedades
        public Queue<Cliente> Cliente
        {
            get
            {
                return this.clientes;
            }
            set
            {
                foreach(Cliente item in PuestoAtencion.)
                {
                    if (item.Numero == )
                    {

                    }
                }
            }
        }
        #endregion

        #region Constructores
        private Negocio()
        {
            clientes = new Queue<Cliente>(0);
        }

        public Negocio(string nombre)
        {
            this.nombre = nombre;
        }
        #endregion

        #region Sobrecargas
        #endregion

    }
}
