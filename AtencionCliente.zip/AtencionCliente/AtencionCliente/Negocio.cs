﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtencionCliente
{
    public class Negocio
    {
        #region Atributos
        private PuestoAtencion caja;
        private Queue<Cliente> clientes;
        private string nombre;
        #endregion

        #region Propiedades
        public Cliente Cliente
        {
            get
            {
                return this.clientes.Dequeue();
            }
            set
            {
                foreach(Cliente item in clientes)
                {
                    if (value.Numero == Cliente.Numero)
                    {
                        break;
                    }
                    clientes.Enqueue(value);
                }
            }
        }
        #endregion

        #region Constructores
        private Negocio()
        {
            clientes = new Queue<Cliente>(0);
            caja = new PuestoAtencion(PuestoAtencion.Puesto.Caja1);
        }

        public Negocio(string nombre)
        {
            this.nombre = nombre;
        }
        #endregion

        #region Sobrecargas
        #endregion

    }
}
