﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace AtencionCliente
{
    public class PuestoAtencion
    {
        #region Enumerador
        public enum Puesto
        {
            Caja1,
            Caja2
        }
        #endregion

        #region Atributos
        private Puesto puesto;
        private static int numeroActual;
        #endregion

        #region Propiedades
        public static int NumeroActual
        {
            get
            {
                return PuestoAtencion.NumeroActual+1;
            }
        }
        #endregion

        #region Constructores
        static PuestoAtencion()
        {
            numeroActual = 0;
        }
        public PuestoAtencion(Puesto puesto)
        {
            this.puesto = puesto;
        }
        #endregion

        #region Metodo
        public bool Atender(Cliente cliente)
        {
            Thread.Sleep(3000);
            return true;
        }
        #endregion
    }
}
