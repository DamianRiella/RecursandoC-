using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Dolar
    {
        #region Atributos
        private double cantidad;
        private static double cotizRespectoDolar;
        #endregion

        #region Contructores

        static Dolar()
        {
            cotizRespectoDolar = 1;
        }

        public Dolar(double cantidad)
        {
            this.cantidad = cantidad;
        }

        public Dolar(double cantidad, double cotizacion): this(cantidad)
        {
            cotizRespectoDolar = cotizacion;
        }
        #endregion

        #region Sobre cargas

        public static explicit operator Euro(Dolar dolar)
        {
            double cant=dolar.GetCantidad()*1.16;
            Euro euro = new Euro(cant, 1.16);
            return euro;      
        }

        public static explicit operator Pesos(Dolar dolar)
        {
          double cant = dolar.GetCantidad() * 38.33;
          Pesos peso = new Pesos(cant, 38.33);
          return peso;
        }

        public static implicit operator Dolar(double d)
        {
          Dolar dolar= new Dolar(d, 1);
          return dolar;
        }

        public static bool operator !=(Dolar d,Euro e)
        {
           return !(d == e);
        }

        public static bool operator !=(Dolar d, Pesos p)
        {
           return !(d == p);
        }

        public static bool operator !=(Dolar d1, Dolar d2)
        {
          return !(d1 == d2);
        }

        public static bool operator ==(Dolar d, Euro e)
        {
          bool retorno = false;
          if(!d.Equals(null) && !e.Equals(null))
          {
            if ((Dolar)e == d)
            {
              retorno = true;
            }
          }

          return retorno;
        }

        public static bool operator ==(Dolar d, Pesos p)
        {
          bool retorno = false;
          if (!d.Equals(null) && !p.Equals(null))
          {
            if ((Dolar)p == d)
            {
              retorno = true;
            }
          }

          return retorno;
        }

        public static bool operator ==(Dolar d1, Dolar d2)
        {
          bool retorno = false;
          if (!d1.Equals(null) && !d2.Equals(null))
          {
            if (d1.cantidad == d2.cantidad)
            {
              retorno = true;
            }
          }
            return retorno;
         }


    #endregion

        #region Metodos
    public static double GetCotizacion()
        {
            return cotizRespectoDolar;
        }

        public double GetCantidad()
        {
            return this.cantidad;
        }
        #endregion

    }
}
