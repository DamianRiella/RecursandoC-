﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Dolar
    {
        #region Atributos
        private double cantidad;
        private static double cotizRespectoDolar;
        #endregion

        #region Contructores

        static Dolar()
        {
            cotizRespectoDolar = 1;
        }

        public Dolar(double cantidad)
        {
            this.cantidad = cantidad;
        }

        public Dolar(double cantidad, double cotizacion): this(cantidad)
        {
            cotizRespectoDolar = cotizacion;
        }
        #endregion

        #region Sobre cargas

        public static explicit operator Euro(Dolar dolar)
        {
        }

        public static explicit operator Pesos(Dolar dolar)
        {
        }

        public static explicit operator Dolar(double dolar)
        {
        }
        #endregion

        #region Metodos
        public static double GetCotizacion()
        {
            return;
        }

        public double GetCantidad()
        {
            return;
        }
        #endregion

    }
}
