﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace VistaForm
{
    public partial class Form1 : Form
    {
        DirectorTecnico dt;

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(dt is null)
            {
                MessageBox.Show("Aún no se ha creado el DT del formulario");
            }
            else
            {
                if (dt.ValidarAptitud())
                {
                    MessageBox.Show("El DT es apto.");
                }
                else
                {
                    MessageBox.Show("El DT no es apto.");
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void labelExperiencia_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            dt = new DirectorTecnico(txtNombre.Text, txtApellido.Text, Convert.ToInt32(nudEdad.Value),
                                    Convert.ToInt32(nudDNI.Value), Convert.ToInt32(nudExperiencia.Value));
            MessageBox.Show("Se ha creado el DT!");
        }
    }
}
