﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        #region Atributos
        private const int cantidadMaximaJugadores = 6;
        private DirectorTecnico directorTecnico;
        private string nombre;
        private List<Jugador> jugadores;
        #endregion

        #region Propiedades
        public DirectorTecnico DirectorTecnico
        {
            set
            {
                if (this.directorTecnico.ValidarAptitud())
                {
                    this.directorTecnico = value;
                }
            }             
        }
        public String Nombre
        {
            get { return this.Nombre; }
        }
        #endregion

        #region Constructores
        private Equipo()
        {
            this.jugadores = new List<Jugador>();
        }
        public Equipo(string nombre)
        {
            this.nombre = nombre;
        }
        #endregion

        #region Metodos y Sobrecargas
        public static explicit operator string(Equipo e)
        {
            string retorno;
            StringBuilder cadena = new StringBuilder();

            if (!e.Equals(null))
            {
                if(e.directorTecnico is null)
                {
                    Console.WriteLine("Sin DT asignado");
                }
                else
                {
                    foreach(Jugador item in e.jugadores)
                    {

                    }
                }
            }
        }
        #endregion
    }
}
