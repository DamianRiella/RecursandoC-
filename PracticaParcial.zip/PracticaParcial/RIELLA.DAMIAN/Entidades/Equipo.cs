﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        #region Atributos
        private const int cantidadMaximaJugadores = 6;
        private DirectorTecnico directorTecnico;
        private string nombre;
        private List<Jugador> jugadores;
        #endregion

        #region Propiedades
        public DirectorTecnico DirectorTecnico
        {
            set
            {
                if (!(directorTecnico is null) && directorTecnico.ValidarAptitud())
                {
                   directorTecnico = value;
                }
            }             
        }
        public String Nombre
        {
            get { return this.Nombre; }
        }
        #endregion

        #region Constructores
        private Equipo()
        {
            jugadores = new List<Jugador>();
        }
        public Equipo(string nombre): this()
        {
            this.nombre = nombre;
        }
        #endregion

        #region Metodos y Sobrecargas
        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        public static explicit operator string(Equipo e)
        {
            string retorno;
            StringBuilder cadena = new StringBuilder();

            if (!e.Equals(null))
            {
                cadena.AppendLine("Nombre de equipo: " + e.nombre);
                cadena.AppendLine("Cantidad de jugadores: " + Convert.ToString(cantidadMaximaJugadores));

                if (e.directorTecnico is null)
                {
                    cadena.AppendLine("DT: Sin DT asignado");
                }
                else
                {
                    cadena.AppendLine(e.directorTecnico.Mostrar());
                }    
                foreach (Jugador item in e.jugadores)
                {
                    cadena.AppendLine(item.Mostrar());
                }
            }
            return retorno = Convert.ToString(cadena);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        /// <param name="j"></param>
        /// <returns></returns>
        public static bool operator ==(Equipo e, Jugador j)
        {
            bool retorno = false;

            if (!e.Equals(null) && !j.Equals(null))
            {
                foreach(Jugador item in e.jugadores)
                {
                    if (j.Dni == item.Dni)
                    {
                        retorno = true;
                    }
                }
            }
            return retorno;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        /// <param name="j"></param>
        /// <returns></returns>
        public static bool operator !=(Equipo e, Jugador j)
        {
            return !(e == j);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        /// <param name="j"></param>
        /// <returns></returns>
        public static Equipo operator +(Equipo e, Jugador j)
        {
            if (!e.Equals(null) && !j.Equals(null))
            {
                if(e != j && e.jugadores.Count < cantidadMaximaJugadores && j.ValidarAptitud())
                {
                    e.jugadores.Add(j);
                }
            }
                return e;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        /// <returns></returns>
        public static bool ValidarEquipo(Equipo e)
        {
            bool retorno = false;
            int delantero=0;
            int defensor=0;
            int arquero = 0;
            int central=0;

            foreach (Jugador item in e.jugadores)
            {
                       
                switch (item.Posicion)
                {
                    case Posicion.Arquero:
                        arquero = arquero + 1;
                        break;
                    case Posicion.Central:
                        central = 1;
                        break;
                    case Posicion.Defensor:
                        defensor = 1;
                        break;
                    case Posicion.Delantero:
                        delantero = 1;
                        break;
                }
            }
            if (delantero == 1 && defensor == 1 && central == 1 && arquero == 1)
            {
                if (!(e.directorTecnico is null) && e.jugadores.Count == cantidadMaximaJugadores)
                {
                    retorno = true;
                }
            }
                
            return retorno;
        }
        #endregion
    }
}
