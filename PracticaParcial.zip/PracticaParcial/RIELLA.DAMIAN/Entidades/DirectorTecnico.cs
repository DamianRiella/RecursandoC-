﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DirectorTecnico : Persona
    {
        #region Atributo
        private int añosExperiencia;
        #endregion

        #region Propiedades
        public int AñosExperiencia
        {
            get { return añosExperiencia; }
            set { añosExperiencia = value; }
        }
        #endregion

        #region Constructor
        public DirectorTecnico(string nombre, string apellido, int edad, int dni, int añosExp): base(nombre,apellido,dni,edad)
        {
            this.añosExperiencia = añosExp;
        }
        #endregion

        #region Metodos
        public override string Mostrar()
        {
            string retorno;
            StringBuilder cadena = new StringBuilder();

            cadena.AppendLine(base.Mostrar());
            cadena.AppendLine("Años de Experiencia: " + añosExperiencia);

            return retorno = Convert.ToString(cadena);
        }

        public override bool ValidarAptitud()
        {
            bool retorno = false;

            if (this.Edad < 65)
            {
                if (this.AñosExperiencia > 2)
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        #endregion
    }
}
