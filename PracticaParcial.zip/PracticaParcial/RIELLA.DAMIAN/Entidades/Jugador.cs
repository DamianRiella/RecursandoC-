﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugador: Persona
    {
        #region Atributos
        private float altura;
        private float peso;
        private Posicion posicion;
        #endregion

        #region Propiedades
        public float Altura
        {
            get { return altura; }
        }
        public float Peso
        {
            get { return peso; }
        }
        public Posicion Posicion
        {
            get { return posicion; }
        }
        #endregion

        #region Contructor
        public Jugador(string nombre, string apellido, int edad, int dni, float altura, float peso, Posicion posicion) : base(nombre,apellido,dni,edad)
        {
            this.altura = altura;
            this.peso = peso;
            this.posicion = posicion;
        }
        #endregion

        #region Metodos
        public override string Mostrar()
        {
            string retorno;
            StringBuilder cadena = new StringBuilder();

            cadena.AppendLine(base.Mostrar());
            cadena.AppendLine("Altura: " + this.Altura);
            cadena.AppendLine("Peso: " + this.Peso);
            cadena.AppendLine("Posicion: " + this.posicion);

            return retorno = Convert.ToString(cadena);
        }

        public bool ValidarEstadoFisico()
        {
            float IMC= this.Peso/(float)(Math.Pow(this.Altura,2));
            bool retorno = false;

                if (IMC<=25 && IMC > 18.5)
                {
                    retorno = true;
                }

            return retorno;
        }

        public override bool ValidarAptitud()
        {
            bool retorno = false;

            if (this.Edad <= 40)
            {
                if (ValidarEstadoFisico())
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        #endregion
    }
}
