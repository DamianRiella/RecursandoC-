﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Persona
    {
        #region Atributos
        private string apellido;
        private string nombre;
        private int edad;
        private int dni;
        #endregion

        #region Propiedades
        public string Apellido
        {
            get { return apellido; }
        }
        public string Nombre
        {
            get { return nombre; }
        }
        public int Edad
        {
            get { return edad; }
        }
        public int Dni
        {
            get { return dni; }
        }
        #endregion

        #region Constructores
        public Persona(string nombre, string apellido, int dni, int edad)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.dni = dni;
            this.edad = edad;
        }
        #endregion

        #region Metodos
        public virtual string Mostrar()
        {
            string retorno;
            StringBuilder cadena = new StringBuilder();

            cadena.AppendLine("Nombre: " + this.Nombre);
            cadena.AppendLine("Apellido: " + this.Apellido);
            cadena.AppendLine("Edad: " + this.Edad);
            cadena.AppendLine("DNI: " + this.Dni);

            return retorno = Convert.ToString(cadena);
        }
        public abstract bool ValidarAptitud();
        #endregion
    }
}
