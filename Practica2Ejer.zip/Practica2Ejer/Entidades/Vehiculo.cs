﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public abstract class Vehiculo
    {
        protected DateTime ingreso;
        private string patente;

        public string Patente
        {
            get { return patente; }
            set
            {
                if (6 == value.Length)
                {
                    patente = value;
                }
            }
        }

        public Vehiculo(string patente)
        {
            Patente = patente;
            ingreso= DateTime.Now.AddHours(-3);
        }

        public abstract string ConsultarDatos();

        public string ToStrong()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Patente {0}", this.Patente);

            return retorno = Convert.ToString(sb);
        }

        public virtual string ImprimirTicket()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(ToString());
            sb.AppendLine("Hora ingreso: "+ ingreso.ToLongTimeString());
            sb.AppendLine("Fecha ingreso: " + ingreso.Day);

            return retorno = Convert.ToString(sb);
        }

        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            bool retorno = false;
            if(!v1.Equals(null) && !v2.Equals(null))
            {
                if(v1.Patente == v2.Patente)
                {
                    if (v1.GetType() == v2.GetType())
                    {
                        retorno = true;
                    }
                }
            }

            return retorno;
        }

        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {        
            return !(v1==v2);
        }

    }
}
