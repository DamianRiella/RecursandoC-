﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Moto: Vehiculo
    {
        private int cilindradas;
        private short ruedas;
        private int valorHora;

        public static Moto()
        {
            Moto.valorHora = 30;
        }
        public Moto(string patente, int cilindradas)
        {

        }
        public Moto(string patente, int cilindradas, short ruedas)
        {

        }
        public Moto(string patente, int cilindradas, short ruedas, int valorHora): this()
        {
            
        }
    }
}
