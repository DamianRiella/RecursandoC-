﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.forms;

namespace Entidades
{
    public  static class PaqueteDAO
    {
        private static SqlConnection conexion;
        private static SqlCommand comando;

        static PaqueteDAO()
        {
            try
            {
                conexion = new SqlConnection("correo-sp-2017");
                conexion.Open();
                MessageBox.Show("Conectado");
            }
            catch(Exception ex)
            {
                MessageBox.Show("No se pudo establecer la conexion. "+ ex.ToString());
            }
        }

        public static bool insertar(Paquete p)
        {
            bool retorno = false;
            string id = Convert.ToInt32(p.TrackingID);
            string estado = p.Estado.ToString();
            string direccion = p.direccionEntrega;
            string alumno = "Damian Riella";

            try
            {
                comando = new SqlCommand("Inserte into Paquete(id, direccionEntrega,trackungID,alumno) value(" + id + ",'" + direccion + "','" + id + "','" +alumno+ "')");
                comando.ExecuteNonQuery();
                retorno = true;
            }
            catch(Exception ex)
            {
                messageBox.Show("No se pudo ingresar datos. " + ex.ToString());
            }

            return retorno;
        }
    }
}
