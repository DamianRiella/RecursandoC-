﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MainCorreo
{
    public static class GuardarString
    {
        public static bool Guardar(this string texto, string archivo)
        {
            bool retorno = false;
            string rutaArchivo = @"C:/Desktop/" + @archivo;

            if (File.Exists(rutaArchivo))
            {
                StreamWriter agregoAlArchivo = File.AppendText(archivo);

                agregoAlArchivo.WriteLine(texto);
                agregoAlArchivo.Close();
                retorno = true;

            }
            else
            {
                StreamWriter ArchivoNuevo = new StreamWriter(archivo);

                ArchivoNuevo.WriteLine(texto);
                ArchivoNuevo.Close();
                retorno = true;

            }

            return retorno;
        }
    }
}
