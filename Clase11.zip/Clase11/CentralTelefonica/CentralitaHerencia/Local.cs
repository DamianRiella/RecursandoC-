using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Local : Llamada
    {
        #region Atributo
        protected float costo;
        #endregion

        #region Propiedades
        public override float CostoLlamada
        {
            get { return CalcularCosto(); }
        }
        #endregion

        #region Constructores
        public Local(Llamada llamada, float costo): this(llamada.NroOrigen, llamada.Duracion, llamada.NroDestino, costo)
        {      
            ///this.duracion = llamada.Duracion;
            //this.nroDestino = llamada.NroDestino;
            //this.nroOrigen = llamada.NroOrigen;
            //this.costo = costo;
        }
        public Local(string origen, float duracion, string destino, float costo) : base(duracion, destino, origen)
        {
            this.costo = costo;
        }
        #endregion

        #region Metodos
        protected override string Mostrar()
        {
            string retorno;
            StringBuilder concatenar = new StringBuilder();

            concatenar.AppendLine(base.Mostrar());
            concatenar.AppendLine("Costo: " + this.costo);

            return retorno = Convert.ToString(concatenar);
        }
        private float CalcularCosto()
        {
            float retorno;
            return retorno=this.costo * this.Duracion;
        }
        public new bool Equals(Object objeto)
        {
          bool retorno = false;
              if(objeto is Local)
              {
            retorno = true;
              }
          return retorno;
        }
        public override string ToString()
        {
          string retorno;
          return retorno=this.Mostrar();  
        }       
        #endregion
    }
}
