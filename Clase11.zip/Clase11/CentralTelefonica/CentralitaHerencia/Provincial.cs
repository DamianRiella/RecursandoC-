﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Provincial: Llamada
    {
        #region Atributos
        Franja franjahoraria;
        #endregion

        #region Propiedades
        public float CostoLlamada
        {
            get { return CalcularCosto(); }
        }
        #endregion

        #region Constructores
        public Provincial(Franja miFranja, Llamada llamada)
        {
            this.franjahoraria = miFranja;
            this.duracion = llamada.Duracion;
            this.nroDestino = llamada.NroDestino;
            this.nroOrigen = llamada.NroOrigen;
        }
        public Provincial(string origen, Franja miFranja, float duracion, string destino):base(duracion,destino,origen)
        {
            this.franjahoraria = miFranja;
        }
        #endregion

        #region Metodos
        public string Mostrar()
        {
            return base.Mostrar() + Convert.ToString(this.CostoLlamada)+ Convert.ToString(this.franjahoraria);
        }
        private float CalcularCosto()
        {
            return this.Duracion*(float)franjahoraria;
        }
        #endregion

        #region Enumeracion
        public enum Franja
        {
            Franja_1= 0.99,
            Franja_2= 1.25,
            Franja_3= 0.66
        }
        #endregion
    }
}
