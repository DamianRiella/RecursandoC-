﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Provincial: Llamada
    {
        #region Atributos
        Franja franjahoraria;
        #endregion

        #region Propiedades
        public float CostoLlamada
        {
            get { return CalcularCosto(); }
        }
        #endregion

        #region Constructores
        public Provincial(Franja miFranja, Llamada llamada):    this(llamada.NroOrigen,miFranja,llamada.Duracion,llamada.NroDestino)
        {
           /* this.franjahoraria = miFranja;
            this.duracion = llamada.Duracion;
            this.nroDestino = llamada.NroDestino;
            this.nroOrigen = llamada.NroOrigen;*/
        }
        public Provincial(string origen, Franja miFranja, float duracion, string destino):base(duracion,destino,origen)
        {
            this.franjahoraria = miFranja;
        }
        #endregion

        #region Metodos
        public string Mostrar()
        {
            string retorno;
            StringBuilder concatenar = new StringBuilder();

            concatenar.AppendLine(base.Mostrar());
            concatenar.AppendLine("Franja Horaria: " + this.franjahoraria);

            return retorno = Convert.ToString(concatenar);
        }
        private float CalcularCosto()
        {
            float retorno;
            switch (franjahoraria)
            {
                case Franja.Franja_1:
                    retorno = this.Duracion * (float)(0.99);
                    break;
                case Franja.Franja_2:
                    retorno = this.Duracion * (float)(1.25);
                    break;
                case Franja.Franja_3:
                    retorno = this.Duracion * (float)(0.66);
                    break;
            }
            return this.Duracion*(float)franjahoraria;
        }
        #endregion

        #region Enumeracion
        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3
        }
        #endregion
    }
}
