using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
  public abstract class Llamada
  {
    #region Atributos
    protected float duracion;
    protected string nroDestino, nroOrigen;
    #endregion

    #region Propiedades
    public float Duracion
    {
      get { return duracion; }
    }
    public string NroDestino
    {
      get { return nroDestino; }
    }
    public string NroOrigen
    {
      get { return nroOrigen; }
    }
    public abstract float CostoLlamada { get; }
    #endregion

    #region Constructor
    public Llamada(float duracion, string nroDestino, string nroOrigen)
    {
      this.duracion = duracion;
      this.nroDestino = nroDestino;
      this.nroOrigen = nroOrigen;
    }
    #endregion

    #region Metodos
    public static int OrdenarPorDuracio(Llamada llamada1, Llamada llamada2)
    {
      int retorno = 0;
      if (!llamada1.Equals(null) && !llamada2.Equals(null))
      {
        List<Llamada> listaLlamada = new List<Llamada>();
        listaLlamada.Add(llamada1);
        listaLlamada.Add(llamada2);

        IEnumerable<Llamada> listaOrdenada = listaLlamada.OrderBy(llamada => llamada.Duracion);
        retorno = 1;
      }
      return retorno;
    }
    protected virtual string Mostrar()
    {
      StringBuilder cadena = new StringBuilder();
      string retorno;

      cadena.AppendLine("Duracio: " + Duracion);
      cadena.AppendLine("Numero destino: " + nroDestino);
      cadena.AppendLine("Numero origen: " + nroOrigen);

      return retorno = Convert.ToString(cadena);
    }
    public static bool operator ==(Llamada llamada1, Llamada llamada2)
    {
      bool retorno = false;
      if (llamada1.NroDestino==llamada2.NroDestino && llamada1.NroOrigen==llamada2.NroOrigen)
      {
        retorno = true;
      }
      return retorno;
    }
    public static bool operator !=(Llamada llamada1, Llamada llamada2)
    {
      return !(llamada1==llamada2);
    }
        #endregion

        #region Enumeracion
        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }
        #endregion
    }
}
