﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Llamada
    {
        #region Atributos
        protected float duracion;
        protected string nroDestino, nroOrigen;
        #endregion

        #region Propiedades
        public float Duracion
        {
            get { return duracion; }
        }
        public string NroDestino
        {
            get { return nroDestino; }
        }
        public string NroOrigen
        {
            get { return nroOrigen; }
        }
        #endregion

        #region Constructor
        public Llamada(float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroDestino = nroDestino;
            this.nroOrigen = nroOrigen;
        }
        #endregion

        #region Metodos
        public static int OrdenarPorDuracio(Llamada llamada1, Llamada llamada2)
        {
            int retorno = 0;
            if (!llamada1.Equals(null) && !llamada2.Equals(null))
            {
                List<Llamada> listaLlamada = new List<Llamada>();
                listaLlamada.Add(llamada1);
                listaLlamada.Add(llamada2);

                IEnumerable<Llamada> listaOrdenada= listaLlamada.OrderBy(llamada => llamada.Duracion);
                retorno = 1;
            }
            return retorno;
        }
        public string Mostrar()
        {
            StringBuilder cadena = new StringBuilder();
            string retorno;

            cadena.AppendLine("Duracio: " + Duracion);
            cadena.AppendLine("Numero destino: " + nroDestino);
            cadena.AppendLine("Numero origen: " + nroOrigen);

            return retorno = Convert.ToString(cadena);
        }
        #endregion

        #region Enumeracion
        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }
        #endregion
    }
}
