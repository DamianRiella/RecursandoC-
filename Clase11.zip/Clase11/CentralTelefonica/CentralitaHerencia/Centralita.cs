﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CentralitaHerencia.Llamada;

namespace CentralitaHerencia
{
    public class Centralita
    {
        #region Atributos
        private List<Llamada> listaLlamadas;
        protected string razonSocial;
        #endregion

        #region Propiedades
        public float GananciaPorLocal
        {
            get { return CalcularGanancias(Llamada.TipoLlamada.Local); }
        }

        public float GananciaPorProvincia
        {
            get { return CalcularGanancias(Llamada.TipoLlamada.Provincial); }
        }

        public float GananciaPorTotal
        {
            get { return CalcularGanancias(Llamada.TipoLlamada.Todas); }
        }

        public List<Llamada> Llamadas
        {
            get { return this.listaLlamadas; }
        }

        #endregion

        #region Constructores
        public Centralita()
        {
            this.listaLlamadas = new List<Llamada>();
        }

        public Centralita(string nombreEmpresa): this()
        {
            razonSocial = nombreEmpresa;
        }
        #endregion

        #region Metodos
        private float CalcularGanancias(TipoLlamada tipo)
        {
            float ganancia = 0;
            string opc = Convert.ToString(tipo);
            switch (opc)
            {
                case "Local":
                    foreach (Llamada item in listaLlamadas)
                    {
                        if(item is Local)
                        {
                            ganancia = ganancia + ((Local)item).CostoLlamada;
                        }
                    }
                    break;
                case "Provincial":
                    foreach (Llamada item in listaLlamadas)
                    {
                        if (item is Provincial)
                        {
                            ganancia = ganancia + ((Provincial)item).CostoLlamada;
                        }
                    }
                    break;
                case "Todas":
                    foreach (Llamada item in listaLlamadas)
                    {
                        if (item is Provincial)
                        {
                            ganancia = ganancia + ((Provincial)item).CostoLlamada;
                        }
                        else
                        {
                            ganancia = ganancia + ((Local)item).CostoLlamada;
                        }
                    }    
                    break;
            }
            return ganancia;
        }
        public string Mostrar()
        {
            StringBuilder cadena=new StringBuilder();
            string retorno;

            cadena.AppendLine("Razon social: " + this.razonSocial);
            cadena.AppendLine("Granancias Totales: " + this.GananciaPorTotal);
            cadena.AppendLine("Granancias Totales: " + this.GananciaPorLocal);
            cadena.AppendLine("Granancias Totales: " + this.GananciaPorProvincia);

            foreach (Llamada item in listaLlamadas)
            {
                cadena.AppendLine(item.Mostrar());
            }

            return retorno = Convert.ToString(cadena);
        }

        public void OrdenarLlamadas()
        {
            listaLlamadas.OrderBy(llamada => llamada.Duracion);
        }
        #endregion
    }
}
