﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersEmpJfVd
{
    public class Empleado: Persona
    {
        private float sueldo;

        public float Sueldo
        {
            get { return sueldo; }
            set { sueldo = value; }
        }

        public Empleado(string nombre, int cuit, float sueldo)
        {
            this.Nombre = nombre;
            this.Cuit = cuit;
            this.Sueldo = sueldo;
        }

        public override string Mostrar()
        {
            StringBuilder cadena = new StringBuilder();
            string retorno;
            cadena.AppendFormat("{0} {1} {2}" + Nombre, Cuit, Sueldo);
            return retorno = Convert.ToString(cadena);
        }
    }
}
