﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersEmpJfVd
{
    public class Vendedor : Empleado
    {
        private int objetivo;

        public int Objetivo
        {
            get { return objetivo; }
            set { objetivo = value; }
        }

        public Vendedor(string nombre, int cuit, float sueldo, int objetivo)
        {
            this.Nombre = nombre;
            this.Cuit = cuit;
            this.Sueldo = sueldo;
            this.Objetivo = objetivo;
        }

        public override string Mostrar()
        {
            return base.Mostrar()+ Convert.ToString(objetivo);
        }
    }
}
