﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersEmpJfVd
{
    public class Jefe : Empleado
    {
        private int bono;

        public int Bono
        {
            get { return bono; }
            set { bono = value; }
        }

        public Jefe(string nombre, int cuit, float sueldo, int bono)
        {
            this.Nombre = nombre;
            this.Cuit = cuit;
            this.Sueldo = sueldo;
            this.Bono = bono;
        }

        public override string Mostrar()
        {
            return base.Mostrar()+ Convert.ToString(bono);
        }
    }
}
