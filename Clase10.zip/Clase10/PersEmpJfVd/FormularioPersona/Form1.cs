﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersEmpJfVd;

namespace FormularioPersona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.comboBox1.DataSource = Enum.GetValues(typeof(EnumeradoPersonas));
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            List<Persona> personas = new List<Persona>();
            string opcionIngresadaComboBox = comboBox1.Text;
            switch (opcionIngresadaComboBox)
            {
                case "Vendedor":
                    personas.Add(new Vendedor(txtNombre.Text,Convert.ToInt32(txtCuit.Text),float.Parse(txtSueldo.Text), Convert.ToInt32(txtObjetivo.Text)));
                    break;
                case "Jefe":
                    personas.Add(new Jefe(txtNombre.Text, Convert.ToInt32(txtCuit.Text), float.Parse(txtSueldo.Text), Convert.ToInt32(txtBono.Text)));
                    break;
                case "Empleado":
                    personas.Add(new Empleado(txtNombre.Text, Convert.ToInt32(txtCuit.Text), float.Parse(txtSueldo.Text)));
                    break;
                default:
                    break;
            }
        }
    }
}
