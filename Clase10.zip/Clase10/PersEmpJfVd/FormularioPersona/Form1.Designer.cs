﻿namespace FormularioPersona
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.labNombre = new System.Windows.Forms.Label();
            this.labCuit = new System.Windows.Forms.Label();
            this.labSueldo = new System.Windows.Forms.Label();
            this.labObjetivo = new System.Windows.Forms.Label();
            this.labBono = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtCuit = new System.Windows.Forms.TextBox();
            this.txtSueldo = new System.Windows.Forms.TextBox();
            this.txtObjetivo = new System.Windows.Forms.TextBox();
            this.txtBono = new System.Windows.Forms.TextBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labNombre
            // 
            this.labNombre.AutoSize = true;
            this.labNombre.Location = new System.Drawing.Point(65, 40);
            this.labNombre.Name = "labNombre";
            this.labNombre.Size = new System.Drawing.Size(44, 13);
            this.labNombre.TabIndex = 0;
            this.labNombre.Text = "Nombre";
            this.labNombre.Click += new System.EventHandler(this.label1_Click);
            // 
            // labCuit
            // 
            this.labCuit.AutoSize = true;
            this.labCuit.Location = new System.Drawing.Point(65, 81);
            this.labCuit.Name = "labCuit";
            this.labCuit.Size = new System.Drawing.Size(32, 13);
            this.labCuit.TabIndex = 1;
            this.labCuit.Text = "CUIT";
            // 
            // labSueldo
            // 
            this.labSueldo.AutoSize = true;
            this.labSueldo.Location = new System.Drawing.Point(65, 117);
            this.labSueldo.Name = "labSueldo";
            this.labSueldo.Size = new System.Drawing.Size(40, 13);
            this.labSueldo.TabIndex = 2;
            this.labSueldo.Text = "Sueldo";
            // 
            // labObjetivo
            // 
            this.labObjetivo.AutoSize = true;
            this.labObjetivo.Location = new System.Drawing.Point(65, 167);
            this.labObjetivo.Name = "labObjetivo";
            this.labObjetivo.Size = new System.Drawing.Size(46, 13);
            this.labObjetivo.TabIndex = 3;
            this.labObjetivo.Text = "Objetivo";
            // 
            // labBono
            // 
            this.labBono.AutoSize = true;
            this.labBono.Location = new System.Drawing.Point(65, 208);
            this.labBono.Name = "labBono";
            this.labBono.Size = new System.Drawing.Size(32, 13);
            this.labBono.TabIndex = 4;
            this.labBono.Text = "Bono";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Jefe",
            "Vendedor",
            "Empleado"});
            this.comboBox1.Location = new System.Drawing.Point(141, 1);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 5;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(141, 33);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(100, 20);
            this.txtNombre.TabIndex = 6;
            // 
            // txtCuit
            // 
            this.txtCuit.Location = new System.Drawing.Point(141, 74);
            this.txtCuit.Name = "txtCuit";
            this.txtCuit.Size = new System.Drawing.Size(100, 20);
            this.txtCuit.TabIndex = 7;
            // 
            // txtSueldo
            // 
            this.txtSueldo.Location = new System.Drawing.Point(141, 117);
            this.txtSueldo.Name = "txtSueldo";
            this.txtSueldo.Size = new System.Drawing.Size(100, 20);
            this.txtSueldo.TabIndex = 8;
            // 
            // txtObjetivo
            // 
            this.txtObjetivo.Location = new System.Drawing.Point(141, 167);
            this.txtObjetivo.Name = "txtObjetivo";
            this.txtObjetivo.Size = new System.Drawing.Size(100, 20);
            this.txtObjetivo.TabIndex = 9;
            // 
            // txtBono
            // 
            this.txtBono.Location = new System.Drawing.Point(141, 208);
            this.txtBono.Name = "txtBono";
            this.txtBono.Size = new System.Drawing.Size(100, 20);
            this.txtBono.TabIndex = 10;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(318, 255);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 11;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 290);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.txtBono);
            this.Controls.Add(this.txtObjetivo);
            this.Controls.Add(this.txtSueldo);
            this.Controls.Add(this.txtCuit);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.labBono);
            this.Controls.Add(this.labObjetivo);
            this.Controls.Add(this.labSueldo);
            this.Controls.Add(this.labCuit);
            this.Controls.Add(this.labNombre);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labNombre;
        private System.Windows.Forms.Label labCuit;
        private System.Windows.Forms.Label labSueldo;
        private System.Windows.Forms.Label labObjetivo;
        private System.Windows.Forms.Label labBono;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtCuit;
        private System.Windows.Forms.TextBox txtSueldo;
        private System.Windows.Forms.TextBox txtObjetivo;
        private System.Windows.Forms.TextBox txtBono;
        private System.Windows.Forms.Button btnAgregar;
    }
}

