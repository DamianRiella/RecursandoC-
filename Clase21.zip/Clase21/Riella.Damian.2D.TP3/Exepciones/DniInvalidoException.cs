﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exepciones
{
    public class DniInvalidoException:Exception
    {
        private string mensajeBase;

        public DniInvalidoException()
        {
            mensajeBase = "Dni invalido.";
        }
        public DniInvalidoException(Exception e)
        {

        }

        public DniInvalidoException(string message)
        {
            mensajeBase = message;
        }

        public DniInvalidoException(string message, Exception e) : this(message)
        {
          
        }
    }
}
