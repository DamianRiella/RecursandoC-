using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesAbstractas
{
  public abstract class Universitario:Persona
  {
    private int legajo;

    public int Legajo
    {
      get { return legajo; }
      set { legajo = value; }
    }

    public Universitario()
    {
      Apellido = "";
      Nombre = "";
      Nacionalidad = ENacionalidad.Argentino;
      DNI = 00000000;
      Legajo = 0;
    }

    public Universitario(string apellido, string nombre, int dni, ENacionalidad nacionalidad, int legajo)
                          : base(nombre, apellido, dni, nacionalidad)
    {
      Legajo = legajo;
    }
  }
}
