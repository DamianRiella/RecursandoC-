using Exepciones;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ClasesAbstractas
{
    public abstract class Persona
    {
        #region Enumerado
        /// <summary>
        /// Enumerado, devuelve la nacionalidad.
        /// </summary>
        public enum ENacionalidad
        {
            Argentino, 
            Extranjero
        }
        #endregion

        #region Atributos
        private string apellido;
        private int dni;
        private ENacionalidad nacionalidad;
        private string nombre;
        #endregion

        #region Propiedades

        /// <summary>
        /// Propiedad, asigna y retorna el valor del atributo Apellido.
        /// </summary>
        public string Apellido
        {
            get { return apellido; }
            set { apellido = ValidarNombreApellido(value); }
        }

        /// <summary>
        /// Propiedad, asigna y retorna el valor del atributo dni.
        /// </summary>
        public int DNI
        {
            get { return dni; }
            set { dni =ValidarDni(nacionalidad,value); }
        }

        /// <summary>
        /// Propiedad, asigna y retorna el valor del atributo nacionalidad.
        /// </summary>
        public ENacionalidad Nacionalidad
        {
            get { return nacionalidad; }
            set { nacionalidad = value; }
        }

        /// <summary>
        /// Propiedad, asigna y retorna el valor del atributo nombre.
        /// </summary>
        public string Nombre
        {
            get { return nombre; }
            set { nombre = ValidarNombreApellido(value); }
        }

        /// <summary>
        /// Propiedad, asigna el valor pasado del tipo string al atributo dni, luego de pasarlo a int.
        /// </summary>
        public string StringToDNI
        {
            set { int.TryParse(value, out dni); }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Costructor sin parametros.
        /// </summary>
        public Persona()
        {
            Apellido = "";
            DNI = 00000000;
            Nacionalidad = ENacionalidad.Argentino;
            Nombre = "";
        }
        /// <summary>
        /// Constructor que resive 3 parametros(nombre, apellido y nacionalidad).
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }
        /// <summary>
        /// Constructor que resive 4 parametros(nombre, apellido, dni en formato int y nacionalidad), llama al costructor de 3 parametros.
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad): this(nombre,apellido,nacionalidad)
        {
            this.DNI = dni;
        }
        /// <summary>
        /// Constructor que resive 4 parametros(nombre, apellido, dni en formato string y nacionalidad), llama al costructor de 3 parametros.
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad): this(nombre,apellido,nacionalidad)
        {
            this.StringToDNI = dni;
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Sobrecarga del metodo ToString, concatena los datos de persona en un solo string utilizando StringBuilder.
        /// </summary>
        /// <returns>Devuelve los datos de persona en un solo string concatenada.</returns>
        public override string ToString()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.Nombre);
            sb.AppendLine(this.Apellido);
            sb.AppendLine(Convert.ToString(this.DNI));
            sb.AppendLine(Convert.ToString(this.Nacionalidad));

            return retorno = Convert.ToString(sb);
        }

        /// <summary>
        /// Metodo para validar dni.
        /// </summary>
        /// <param name="nacionalidad">Nacionalidad.</param>
        /// <param name="dato">Dni a validar</param>
        /// <returns>Si es true devuelve el dni y si es false lanza una exception y devuelve 0.</returns>
        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
          NacionalidadInvalidaException eNacionalidad = new NacionalidadInvalidaException("Dni invalido.");
          DniInvalidoException eDni = new DniInvalidoException("Dni invalido.");
          Regex valiDni = new Regex(@"^\b{8}[0-9]+$");
          string datoString = Convert.ToString(dato);
          int retorno = 0;

            if (valiDni.IsMatch(datoString))
            {

              if (nacionalidad == ENacionalidad.Argentino && (dato >= 1 && dato <= 89999999))
              {
                retorno = dato;
              }
              else if (nacionalidad == ENacionalidad.Extranjero && (dato >= 90000000 && dato <= 99999999))
              {
                retorno = dato;
              }
              else
              {
                throw eNacionalidad;//si los datos no son correctos lanzo la exception.
              }
            }
            else
            {
              throw eDni;
            }

           return retorno;
      
        }

        /// <summary>
        /// Metodo para validar dni pasado como string, reutiliza el codigo del metodo ValidarDni(Enacionalidad,int);
        /// </summary>
        /// <param name="nacionalidad">Nacionalidad</param>
        /// <param name="dato">Dni a validar</param>
        /// <returns>Si es true devuelve el dni y si es false lanza una exception y devuelve 0.</returns>
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
          int retorno;
          int datoPasadoInt;
            
          datoPasadoInt = int.Parse(dato);
          retorno = ValidarDni(nacionalidad, datoPasadoInt);
          
          return retorno;
       }

        /// <summary>
        /// Metodo para validar nombres y apellidos.
        /// </summary>
        /// <param name="dato">nombre o apellido a validar</param>
        /// <returns>Si es true devuelve el nombre/apellido que fue pasado por parametro, 
        ///          de lo contrario devuelve un mensage de error.</returns>
        private string ValidarNombreApellido(string dato)
        {
            Regex Val = new Regex(@"^[a-zA-Z]+$");//Expreciones regulares.
          
            if (!Val.IsMatch(dato))//controlo que el nombre sea solo letras.
            {
                dato ="El nombre solo debe contener letras.";
            }
            return dato;
        }
        #endregion
    }
}
