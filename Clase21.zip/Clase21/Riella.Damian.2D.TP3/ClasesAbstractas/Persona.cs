using Exepciones;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesAbstractas
{
    abstract class Persona
    {
        #region Enumerado
        /// <summary>
        /// Enumerado, devuelve la nacionalidad.
        /// </summary>
        public enum ENacionalidad
        {
            Argentino, 
            Extranjero
        }
        #endregion

        #region Atributos
        private string apellido;
        private int dni;
        private ENacionalidad nacionalidad;
        private string nombre;
        #endregion

        #region Propiedades

        /// <summary>
        /// Propiedad, asigna y retorna el valor del atributo Apellido.
        /// </summary>
        public string Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }

        /// <summary>
        /// Propiedad, asigna y retorna el valor del atributo dni.
        /// </summary>
        public int DNI
        {
            get { return dni; }
            set { dni = value; }
        }

        /// <summary>
        /// Propiedad, asigna y retorna el valor del atributo nacionalidad.
        /// </summary>
        public ENacionalidad Nacionalidad
        {
            get { return nacionalidad; }
            set { nacionalidad = value; }
        }

        /// <summary>
        /// Propiedad, asigna y retorna el valor del atributo nombre.
        /// </summary>
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        /// <summary>
        /// Propiedad, asigna el valor pasado del tipo string al atributo dni, luego de pasarlo a int.
        /// </summary>
        public string StringToDNI
        {
            set { }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Costructor sin parametros.
        /// </summary>
        public Persona()
        {
            Apellido = "";
            DNI = 0;
            Nacionalidad = 0;
            Nombre = "";
        }
        /// <summary>
        /// Constructor que resive 3 parametros(nombre, apellido y nacionalidad).
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }
        /// <summary>
        /// Constructor que resive 4 parametros(nombre, apellido, dni en formato int y nacionalidad), llama al costructor de 3 parametros.
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad): this(nombre,apellido,nacionalidad)
        {
            this.DNI = dni;
        }
        /// <summary>
        /// Constructor que resive 4 parametros(nombre, apellido, dni en formato string y nacionalidad), llama al costructor de 3 parametros.
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad): this(nombre,apellido,nacionalidad)
        {
            this.StringToDNI = dni;
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Sobrecarga del metodo ToString, concatena los datos de persona en un solo string utilizando StringBuilder.
        /// </summary>
        /// <returns>Devuelve los datos de persona en un solo string concatenada.</returns>
        public string ToString()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.Nombre);
            sb.AppendLine(this.Apellido);
            sb.AppendLine(Convert.ToString(this.DNI));
            sb.AppendLine(Convert.ToString(this.Nacionalidad));

            return retorno = Convert.ToString(sb);
        }

        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
          int retorno = 0;
          if (nacionalidad==ENacionalidad.Argentino && (dato >= 1 && dato <= 89999999))
          {
               retorno = dato;
          }
          if(nacionalidad==ENacionalidad.Extranjero && (dato >= 90000000 && dato <= 99999999))
          {   
              retorno = dato;
          }

           return retorno;
      
        }

        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
          int retorno;
          int datoPasadoInt;

          datoPasadoInt = int.Parse(dato);
          retorno = ValidarDni(nacionalidad, datoPasadoInt);
          
          return retorno;
       }

        private string ValidarNombreApellido(string dato)
        {
          string retorno=dato;
          List<char> Validos = new List<char>() { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'Ñ', 'O', 'P',
                                                  'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z','Ü', ' ',};

      foreach (char a in nombre)
              {
                if (!Validos.Contains(a))
                {

                  retorno = "Nombre invalido";

                }
              }
         return retorno;
         }
        #endregion
    }
}
