﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class SateliteException:Exception
    {
        public SateliteException() : base() { }

        public static Exception SatMetodo(Planeta<Satelite> lista, Satelite sat)
        {
            string retorno = "No se puede crear el satelite.";

            if (lista == sat)
            {
                throw retorno;
            }

            
        }
    }
}
