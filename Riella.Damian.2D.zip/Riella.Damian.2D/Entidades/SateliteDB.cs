﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;   

namespace Entidades
{
    public class SateliteDB
    {
        private SqlConnection conexion;
        private SqlCommand comando;

        public SateliteDB()
        {
            conexion = new SqlConnection();
            comando = new SqlCommand();
            this.comando.CommandType = System.Data.CommandType.Text;
            this.comando.Connection = this.conexion;
        }

        public bool Guardar(string tabla,Satelite satelite)
        {
            bool retorno = false;
            string cadena= "INSERT INTO " + tabla + " (duraOrbita,duracionRotacion,nombre) SELECT " + satelite.DuraOrbita + "," + satelite.DuraRotacion + ",'"+satelite.Nombre+"'";

            try
            {
                comando.CommandText = cadena;
                conexion.Open();
                comando.ExecuteNonQuery();
                retorno = true;

            }
            catch(Exception)
            {
                throw new SateliteException();
            }
            finally
            {
                if (this.conexion.State == ConnectionState.Open)
                    this.conexion.Close();
            }

            return retorno;
        }

        public List<Satelite> Leer(string tabla)
        {
            List<Satelite> listaSatelites = new List<Satelite>();

            try
            {
                this.comando.CommandText = "SELECT duraOrbita,duracionRotacion,nombre  FROM " + tabla;
                this.conexion.Open();
                SqlDataReader datos = this.comando.ExecuteReader();

                while (datos.Read())
                {
                    listaSatelites.Add(new Satelite((int)datos["duraOrbita"], (int)datos["duracionRotacion"], datos["nombre"].ToString()));
                }

                datos.Close();
                return listaSatelites;
            }
            catch (Exception)
            {
                throw new SateliteException();
            }
            finally
            {
                if (this.conexion.State == ConnectionState.Open)
                    this.conexion.Close();
            }

        }



    }
}
