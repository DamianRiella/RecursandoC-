﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Entidades
{
    public static class AstroExtension
    {
        public static bool Guardar(this Planeta<Satelite> plan)
        {
            bool retorno = false;

            StreamWriter archivoNuevo = new StreamWriter("archivo");

            try
            {
                foreach (Satelite item in plan.Satelites)
                {
                    archivoNuevo.WriteLine(item.ToString());
                }

                archivoNuevo.Close();
                retorno = true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                archivoNuevo.Close();
            }

            return retorno;   
        }

        public static bool Guardar(this Satelite sat)
        {
            string archivoNuevo = sat.ToString();
            XmlSerializer serializer = new XmlSerializer(Satelite);
            TextWriter writer = new StreamWriter(archivoNuevo);
            bool retorno = false;

            try
            {
                serializer.Serialize(writer, sat);
                writer.Close();
                retorno = true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                writer.Close();
            }
            return retorno;
            
        }


    }
}
