﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Ferreteria:Prodructo
    {
        private float peso;

        public float Peso { get { return peso; } set { peso = value; } }

        public Ferreteria(int id, string descripcion, float peso) : base(id, descripcion)
        {
            this.Peso = peso;
        }
    }
}
