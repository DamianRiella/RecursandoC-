﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Estanteria<T> where T:Prodructo
    {
        private int tamaño;
        private T[] productos;

        public int Tamaño { get { return tamaño; } set { tamaño = value; } }
        public T[] Productos { get { return productos; } set { productos = value; } }

        public Estanteria(int tamaño, T[] productos)
        {
            this.Tamaño = tamaño;
            this.Productos = productos;
        }

        public static bool operator +(T producto, Estanteria<T> estanteria)
        {
            bool retorno = false;

            foreach (T item in estanteria.Productos)
            {
                if (item.Id_prod != producto.Id_prod)
                {
                    for(int i=0; i<estanteria.Tamaño; i++)
                    {
                        if(estanteria.Productos[i] is null)
                        {
                            estanteria.Productos[i] = producto;
                            retorno = true;
                        }
                    }
                }
            }
            return retorno;
        }
        public static bool operator -(T producto, Estanteria<T> estanteria)
        {
            bool retorno = false;

            foreach (T item in estanteria.Productos)
            {
                if (item.Id_prod == producto.Id_prod)
                {
                    estanteria.Productos[item.Id_prod] = null;
                    retorno = true;
                }
            }

            return retorno;
        }
    }
}
