﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Alimenticio: Prodructo
    {
        private double vencimiento;

        public double Vencimiento { get { return vencimiento; } set { vencimiento = value; } }

        public Alimenticio() : base()
        {
            Vencimiento = 0;
        }
        public Alimenticio(int id, string descripcion, double vencimiento): base(id, descripcion)
        {
            this.Vencimiento = vencimiento;
        }
    }
}
