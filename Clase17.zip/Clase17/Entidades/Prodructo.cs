﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Prodructo
    {
        private int id_prod;
        private string descripcion;

        public int Id_prod { get { return id_prod; } set { id_prod = value; } }
        public string Descripcion { get { return descripcion; } set { descripcion = value; } }

        public Prodructo()
        {
            id_prod = 0;
            descripcion = "";
        }
        public Prodructo(int id, string descripcion)
        {
            Id_prod = id;
            Descripcion = descripcion;
        }
    }
}
