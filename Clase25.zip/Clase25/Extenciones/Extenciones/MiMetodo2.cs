﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extenciones
{
    public static class MiMetodo2
    {
        public static string ContarSignos(this string cadena)
        {
            int contComa = 0;
            int contPunto = 0;
            int contPuntoComa = 0;
            StringBuilder sb = new StringBuilder();
            String retorno;

            foreach (char item in cadena)
            {
                if (item == '.')
                    contPunto++;
                if (item == ',')
                    contComa++;
                if (item == ';')
                    contPuntoComa++;
            }

            sb.AppendLine("Cantidad de comas: "+ Convert.ToString(contComa));
            sb.AppendLine("Cantidad de comas: " + Convert.ToString(contPunto));
            sb.AppendLine("Cantidad de comas: " + Convert.ToString(contPuntoComa));

            return retorno = Convert.ToString(sb);
        }
    }
}
