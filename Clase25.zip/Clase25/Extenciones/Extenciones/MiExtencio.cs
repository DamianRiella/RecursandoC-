﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extenciones
{
    public static class MiExtencio
    {
        public static void CantidadDeDigitos(this long numero)
        {
            string s=Convert.ToString(numero);
            Console.WriteLine("Numero de {0} digitos.", s.Length);
            
            return;
        }
    }
}
