﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    public class Producto
    {
        #region Atributos
        private string codigoDeBarra;
        private string marca;
        private float precio;
        #endregion

        #region Constructor
        public Producto(string marca, string codigo, float precio)
        {
            this.codigoDeBarra = codigo;
            this.marca = marca;
            this.precio = precio;
        }
        #endregion

        #region Metodos

        #region Get
        public string GetMarca()
        {
            return this.marca;
        }

        public float GetPrecio()
        {
            return this.precio;
        }
        #endregion

        #region Mostrar
        public static string MostrarProducto(Producto producto)
        {
            StringBuilder concatenar = new StringBuilder();
            string retorno;

            concatenar.AppendLine("Marca: " + producto.marca);
            concatenar.AppendLine("Precio: " + producto.precio);
            concatenar.AppendLine("Codigo de Barra: " + producto.codigoDeBarra);

            return retorno = Convert.ToString(concatenar);
        }
        #endregion

        #region Sobrecargas
        /// <summary>
        /// Sobrecargamos el operador de conversion explicito, convierte el atributo codigoDeBarra de la clase Producto a string.
        /// </summary>
        /// <param name="producto">Objeto a convertir</param>
        public static explicit operator string(Producto producto)
        {
            string retorno;

            return retorno = (string)producto.codigoDeBarra;
        }

        /// <summary>
        /// Sobrecargamos el operador == para que me compare dos atributos de dos objetos diferentes.
        /// </summary>
        /// <param name="productoUno">primer objeto producto</param>
        /// <param name="productoDos">segundo objeto producto</param>
        /// <returns></returns>
        public static bool operator ==(Producto productoUno, Producto productoDos)
        {
            if(!(productoUno is null)||!(pe))
                bool retorno = false;

                if (productoUno.marca==productoDos.marca)
                {
                    if (productoUno.codigoDeBarra == productoDos.codigoDeBarra)
                    {
                        retorno = true;
                    }
                }

            return retorno;
        }

        /// <summary>
        /// Sobrecargamos el operador != reutilizando la sobrecarga de operador ==.
        /// </summary>
        /// <param name="productoUno">Primer objeto a convertir</param>
        /// <param name="productoDos">Segundo objeto a convertir</param>
        /// <returns></returns>
        public static bool operator !=(Producto productoUno, Producto productoDos)
        {
            return !(productoUno == productoDos);
        }

        /// <summary>
        /// Sobrecargamos el operador ==, para que nos compare el atributo marca de un objeto con un string para so por parametro.
        /// </summary>
        /// <param name="producto">Objeto a comparar</param>
        /// <param name="marca">String a comparar</param>
        /// <returns></returns>
        public static bool operator ==(Producto producto, string marca)
        {
            bool retorno = false;

            if (producto.marca == marca)
            {
                retorno = true;
            }

            return retorno;
        }

        /// <summary>
        /// Sobrecargamos el operador != reutilizando la sobrecarga de operador ==.
        /// </summary>
        /// <param name="producto">>Objeto a comparar</param>
        /// <param name="marca">String a comparar</param>
        /// <returns></returns>
        public static bool operator !=(Producto producto, string marca)
        {
            return !(producto.marca == marca);
        }
        #endregion


        #endregion
    }
}
