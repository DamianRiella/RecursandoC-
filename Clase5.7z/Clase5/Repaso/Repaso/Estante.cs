﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    public class Estante
    {
        #region Atributos
        private int ubicacionEstante;
        private Producto[] productos;
        #endregion

        #region Constructores
        private Estante(int capacidad)
        {
            this.productos = new Producto[capacidad];
        }

        public Estante(int capacidad, int ubicacion):this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }
        #endregion

        #region Metodos
        public Producto[] GetProducto()
        {
            return productos;
        }

        public static string MostrarEstante(Estante estante)
        {
            StringBuilder concatenar= new StringBuilder();
            Producto[] productos = estante.GetProducto();
            string retorno="";

            foreach(Producto i in productos)
            { 
                retorno = Producto.MostrarProducto(i);
            }

            return retorno;
        }
        #endregion

        #region Sobrecarga

        public static bool operator ==(Estante estante, Producto producto)
        {
            if (!(estante is null) || !(producto is null))
            {

                Producto[] produc = estante.GetProducto();

                foreach (Producto prod in produc)
                {

                    if (prod == producto)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public static bool operator !=(Estante estante, Producto producto)
        {
            return !(estante == producto);
        }

        public static bool operator +(Estante estante, Producto producto)
        {
            Producto[] produc = estante.GetProducto();
            bool retorno = false;

            if (estante != producto)
            {
                for (int i = 0; i < produc.Length ; i++)
                {
                    if (produc[i] is null)
                    {
                        estante.productos[i] = producto;
                        retorno = true;
                        break;
                    }
                }
            }
            return retorno;
        }

        public static Estante operator -(Estante estante, Producto producto)
        {
            Producto[] produc = estante.GetProducto();
    
                for (int i = 0; i < produc.Length; i++)
                {
                    if (produc[i]==producto)
                    {
                        estante.productos[i] = null;
                    }
                }
            return estante;
        }
        #endregion
    }
}
