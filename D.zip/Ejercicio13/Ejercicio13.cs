﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio13
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero;
            string deciBinario, binarioDecimal;

                Console.WriteLine("Ingrese numero decimal:");
                double.TryParse(Console.ReadLine(), out numero);

                    deciBinario= Conversor.DecimalBinario(numero);
                    Console.WriteLine("Numero convertido:{0}", deciBinario);
                    Console.ReadKey();

            Console.WriteLine("Ingrese numero binario:");
            binarioDecimal= Console.ReadLine();

                    binarioDecimal = Conversor.BinarioDecimal(binarioDecimal).ToString();
                    Console.WriteLine("Numero convertido:{0}", binarioDecimal);
                    Console.ReadKey();
        }
    }
}
