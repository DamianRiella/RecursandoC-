﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio14
{
    class Program
    {
        static void Main(string[] args)
        {
            bool opc;
            double resultado;
            int num;

            Console.WriteLine("Que desea calcula?");
            Console.WriteLine("1_Cuadrado");
            Console.WriteLine("2_Triangulo");
            Console.WriteLine("3_Circulo");
            opc= int.TryParse(Console.ReadLine(), out num);

            if (opc != false)
            {
                switch (num)
                {
                    case 1:
                        double lado;

                        Console.WriteLine("Ingrese el lado de cuadrado:");
                        opc = double.TryParse(Console.ReadLine(),out lado);

                            if (opc != false)
                            {
                                resultado = CalculoDeArea.CalculaCuadrado(lado);
                                Console.WriteLine("El area del cuadrado es: {0}", resultado);
                                Console.ReadKey();
                            }
                            else
                            {
                                Console.WriteLine("Error. Numero no existe.");
                                Console.ReadKey();
                            }

                        break;

                    case 2:
                        double bas, altura;

                        Console.WriteLine("Ingrese la base del triangulo:");
                        opc = double.TryParse(Console.ReadLine(),out bas);

                            if (opc != false)
                            {
                                Console.WriteLine("Ingrese la altura del triangulo:");
                                opc = double.TryParse(Console.ReadLine(), out altura);

                                    if (opc != false)
                                    {
                                        resultado = CalculoDeArea.CalculaTriangulo(bas, altura);
                                        Console.WriteLine("El area del triangulo es: {0}", resultado);
                                        Console.ReadKey();
                                    }
                                    else
                                    {
                                        Console.WriteLine("Error. Numero no existe.");
                                        Console.ReadKey();
                                    }
                            }
                            else
                            {
                                Console.WriteLine("Error. Numero no existe.");
                                Console.ReadKey();
                            }

                      break;

                    case 3:
                        double circunferencia;

                        Console.WriteLine("Ingrese la circunferencia del circulo:");
                        opc = double.TryParse(Console.ReadLine(),out circunferencia);

                            if (opc != false)
                            {
                                resultado = CalculoDeArea.CalculaCirculo(circunferencia);
                                Console.WriteLine("El area del circulo es: {0}", resultado);
                                Console.ReadKey();
                            }
                            else
                            {
                                Console.WriteLine("Error. Numero no existe.");
                                Console.ReadKey();
                            }

                        break;

                    default:
                        Console.WriteLine("Error.Numero incorrecto.");
                        Console.ReadKey();
                        break;
                }
            }

        }
    }
}
