﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio14
{
    public class CalculoDeArea
    {

        public static double CalculaCuadrado(double lado)
        {
            double resultado;
            return resultado = lado*lado;
        }
        public static double CalculaTriangulo(double bas, double altura)
        {
            double resultado;
            return resultado = (bas * altura)/2;
        }
        public static double CalculaCirculo(double num)
        {
            double resultado;
            return resultado = 3.14159*(num*num);
        }
    }
}
