﻿using System;

namespace Riella.Damian._2019
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
