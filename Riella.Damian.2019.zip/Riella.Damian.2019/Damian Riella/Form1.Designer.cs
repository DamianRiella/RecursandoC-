﻿namespace Damian_Riella
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.labNombre = new System.Windows.Forms.Label();
            this.labelTiempoOrbita = new System.Windows.Forms.Label();
            this.labelTiempoRotacion = new System.Windows.Forms.Label();
            this.labelCantLunas = new System.Windows.Forms.Label();
            this.labelTipoPlaneta = new System.Windows.Forms.Label();
            this.btnAgregarPlaneta = new System.Windows.Forms.Button();
            this.btnInformacion = new System.Windows.Forms.Button();
            this.btnAgregarSatelite = new System.Windows.Forms.Button();
            this.btnMovesAstros = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.labelCompletOrbita = new System.Windows.Forms.Label();
            this.labelCompletRotacion = new System.Windows.Forms.Label();
            this.labelNomSatelite = new System.Windows.Forms.Label();
            this.labelPlaneta = new System.Windows.Forms.Label();
            this.cmbTipoPLaneta = new System.Windows.Forms.ComboBox();
            this.cmbEligirPLaneta = new System.Windows.Forms.ComboBox();
            this.txtNombrePlaneta = new System.Windows.Forms.TextBox();
            this.txtTiempoCompletOrbita = new System.Windows.Forms.TextBox();
            this.txtNombreSatelite = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            this.SuspendLayout();
            // 
            // labNombre
            // 
            this.labNombre.AutoSize = true;
            this.labNombre.Location = new System.Drawing.Point(81, 28);
            this.labNombre.Name = "labNombre";
            this.labNombre.Size = new System.Drawing.Size(99, 13);
            this.labNombre.TabIndex = 0;
            this.labNombre.Text = "Nombre del planeta";
            this.labNombre.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelTiempoOrbita
            // 
            this.labelTiempoOrbita.AutoSize = true;
            this.labelTiempoOrbita.Location = new System.Drawing.Point(81, 68);
            this.labelTiempoOrbita.Name = "labelTiempoOrbita";
            this.labelTiempoOrbita.Size = new System.Drawing.Size(135, 13);
            this.labelTiempoOrbita.TabIndex = 1;
            this.labelTiempoOrbita.Text = "Tiempo en completar orbita";
            this.labelTiempoOrbita.Click += new System.EventHandler(this.label2_Click);
            // 
            // labelTiempoRotacion
            // 
            this.labelTiempoRotacion.AutoSize = true;
            this.labelTiempoRotacion.Location = new System.Drawing.Point(81, 106);
            this.labelTiempoRotacion.Name = "labelTiempoRotacion";
            this.labelTiempoRotacion.Size = new System.Drawing.Size(138, 13);
            this.labelTiempoRotacion.TabIndex = 2;
            this.labelTiempoRotacion.Text = "Tiempo ccompletar rotacion";
            this.labelTiempoRotacion.Click += new System.EventHandler(this.label3_Click);
            // 
            // labelCantLunas
            // 
            this.labelCantLunas.AutoSize = true;
            this.labelCantLunas.Location = new System.Drawing.Point(81, 151);
            this.labelCantLunas.Name = "labelCantLunas";
            this.labelCantLunas.Size = new System.Drawing.Size(92, 13);
            this.labelCantLunas.TabIndex = 3;
            this.labelCantLunas.Text = "Cantidad de lunas";
            // 
            // labelTipoPlaneta
            // 
            this.labelTipoPlaneta.AutoSize = true;
            this.labelTipoPlaneta.Location = new System.Drawing.Point(81, 190);
            this.labelTipoPlaneta.Name = "labelTipoPlaneta";
            this.labelTipoPlaneta.Size = new System.Drawing.Size(82, 13);
            this.labelTipoPlaneta.TabIndex = 4;
            this.labelTipoPlaneta.Text = "Tipo de Planeta";
            // 
            // btnAgregarPlaneta
            // 
            this.btnAgregarPlaneta.Location = new System.Drawing.Point(48, 229);
            this.btnAgregarPlaneta.Name = "btnAgregarPlaneta";
            this.btnAgregarPlaneta.Size = new System.Drawing.Size(324, 36);
            this.btnAgregarPlaneta.TabIndex = 5;
            this.btnAgregarPlaneta.Text = "Agregar Planeta";
            this.btnAgregarPlaneta.UseVisualStyleBackColor = true;
            this.btnAgregarPlaneta.Click += new System.EventHandler(this.btnAgregarPlaneta_Click);
            // 
            // btnInformacion
            // 
            this.btnInformacion.Location = new System.Drawing.Point(48, 271);
            this.btnInformacion.Name = "btnInformacion";
            this.btnInformacion.Size = new System.Drawing.Size(666, 43);
            this.btnInformacion.TabIndex = 6;
            this.btnInformacion.Text = "Mostrar Imformacion";
            this.btnInformacion.UseVisualStyleBackColor = true;
            // 
            // btnAgregarSatelite
            // 
            this.btnAgregarSatelite.Location = new System.Drawing.Point(378, 229);
            this.btnAgregarSatelite.Name = "btnAgregarSatelite";
            this.btnAgregarSatelite.Size = new System.Drawing.Size(336, 36);
            this.btnAgregarSatelite.TabIndex = 7;
            this.btnAgregarSatelite.Text = "Agregar Satelite";
            this.btnAgregarSatelite.UseVisualStyleBackColor = true;
            this.btnAgregarSatelite.Click += new System.EventHandler(this.btnAgregarSatelite_Click);
            // 
            // btnMovesAstros
            // 
            this.btnMovesAstros.Location = new System.Drawing.Point(48, 320);
            this.btnMovesAstros.Name = "btnMovesAstros";
            this.btnMovesAstros.Size = new System.Drawing.Size(666, 36);
            this.btnMovesAstros.TabIndex = 8;
            this.btnMovesAstros.Text = "Mover Astros";
            this.btnMovesAstros.UseVisualStyleBackColor = true;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(221, 106);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown1.TabIndex = 9;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.nupTiempoCompletRotacion_ValueChanged);
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(222, 144);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown2.TabIndex = 10;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(567, 149);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown3.TabIndex = 11;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(567, 99);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown4.TabIndex = 12;
            // 
            // labelCompletOrbita
            // 
            this.labelCompletOrbita.AutoSize = true;
            this.labelCompletOrbita.Location = new System.Drawing.Point(414, 105);
            this.labelCompletOrbita.Name = "labelCompletOrbita";
            this.labelCompletOrbita.Size = new System.Drawing.Size(138, 13);
            this.labelCompletOrbita.TabIndex = 13;
            this.labelCompletOrbita.Text = "Tiempor en completar orbita";
            // 
            // labelCompletRotacion
            // 
            this.labelCompletRotacion.AutoSize = true;
            this.labelCompletRotacion.Location = new System.Drawing.Point(414, 153);
            this.labelCompletRotacion.Name = "labelCompletRotacion";
            this.labelCompletRotacion.Size = new System.Drawing.Size(147, 13);
            this.labelCompletRotacion.TabIndex = 15;
            this.labelCompletRotacion.Text = "Tiempo en completar rotacion";
            // 
            // labelNomSatelite
            // 
            this.labelNomSatelite.AutoSize = true;
            this.labelNomSatelite.Location = new System.Drawing.Point(414, 68);
            this.labelNomSatelite.Name = "labelNomSatelite";
            this.labelNomSatelite.Size = new System.Drawing.Size(97, 13);
            this.labelNomSatelite.TabIndex = 16;
            this.labelNomSatelite.Text = "Nombre del satelite";
            // 
            // labelPlaneta
            // 
            this.labelPlaneta.AutoSize = true;
            this.labelPlaneta.Location = new System.Drawing.Point(414, 28);
            this.labelPlaneta.Name = "labelPlaneta";
            this.labelPlaneta.Size = new System.Drawing.Size(43, 13);
            this.labelPlaneta.TabIndex = 17;
            this.labelPlaneta.Text = "Planeta";
            // 
            // cmbTipoPLaneta
            // 
            this.cmbTipoPLaneta.FormattingEnabled = true;
            this.cmbTipoPLaneta.Location = new System.Drawing.Point(221, 182);
            this.cmbTipoPLaneta.Name = "cmbTipoPLaneta";
            this.cmbTipoPLaneta.Size = new System.Drawing.Size(121, 21);
            this.cmbTipoPLaneta.TabIndex = 18;
            this.cmbTipoPLaneta.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // cmbEligirPLaneta
            // 
            this.cmbEligirPLaneta.FormattingEnabled = true;
            this.cmbEligirPLaneta.Location = new System.Drawing.Point(567, 21);
            this.cmbEligirPLaneta.Name = "cmbEligirPLaneta";
            this.cmbEligirPLaneta.Size = new System.Drawing.Size(121, 21);
            this.cmbEligirPLaneta.TabIndex = 19;
            // 
            // txtNombrePlaneta
            // 
            this.txtNombrePlaneta.Location = new System.Drawing.Point(222, 21);
            this.txtNombrePlaneta.Name = "txtNombrePlaneta";
            this.txtNombrePlaneta.Size = new System.Drawing.Size(120, 20);
            this.txtNombrePlaneta.TabIndex = 20;
            // 
            // txtTiempoCompletOrbita
            // 
            this.txtTiempoCompletOrbita.Location = new System.Drawing.Point(222, 61);
            this.txtTiempoCompletOrbita.Name = "txtTiempoCompletOrbita";
            this.txtTiempoCompletOrbita.Size = new System.Drawing.Size(120, 20);
            this.txtTiempoCompletOrbita.TabIndex = 21;
            // 
            // txtNombreSatelite
            // 
            this.txtNombreSatelite.Location = new System.Drawing.Point(567, 61);
            this.txtNombreSatelite.Name = "txtNombreSatelite";
            this.txtNombreSatelite.Size = new System.Drawing.Size(120, 20);
            this.txtNombreSatelite.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 367);
            this.Controls.Add(this.txtNombreSatelite);
            this.Controls.Add(this.txtTiempoCompletOrbita);
            this.Controls.Add(this.txtNombrePlaneta);
            this.Controls.Add(this.cmbEligirPLaneta);
            this.Controls.Add(this.cmbTipoPLaneta);
            this.Controls.Add(this.labelPlaneta);
            this.Controls.Add(this.labelNomSatelite);
            this.Controls.Add(this.labelCompletRotacion);
            this.Controls.Add(this.labelCompletOrbita);
            this.Controls.Add(this.numericUpDown4);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.btnMovesAstros);
            this.Controls.Add(this.btnAgregarSatelite);
            this.Controls.Add(this.btnInformacion);
            this.Controls.Add(this.btnAgregarPlaneta);
            this.Controls.Add(this.labelTipoPlaneta);
            this.Controls.Add(this.labelCantLunas);
            this.Controls.Add(this.labelTiempoRotacion);
            this.Controls.Add(this.labelTiempoOrbita);
            this.Controls.Add(this.labNombre);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labNombre;
        private System.Windows.Forms.Label labelTiempoOrbita;
        private System.Windows.Forms.Label labelTiempoRotacion;
        private System.Windows.Forms.Label labelCantLunas;
        private System.Windows.Forms.Label labelTipoPlaneta;
        private System.Windows.Forms.Button btnAgregarPlaneta;
        private System.Windows.Forms.Button btnInformacion;
        private System.Windows.Forms.Button btnAgregarSatelite;
        private System.Windows.Forms.Button btnMovesAstros;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label labelCompletOrbita;
        private System.Windows.Forms.Label labelCompletRotacion;
        private System.Windows.Forms.Label labelNomSatelite;
        private System.Windows.Forms.Label labelPlaneta;
        private System.Windows.Forms.ComboBox cmbTipoPLaneta;
        private System.Windows.Forms.ComboBox cmbEligirPLaneta;
        private System.Windows.Forms.TextBox txtNombrePlaneta;
        private System.Windows.Forms.TextBox txtTiempoCompletOrbita;
        private System.Windows.Forms.TextBox txtNombreSatelite;
    }
}

