﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Astro
    {
        private int duracionOrbita;
        private int duarcionRotacion;
        protected string nombre;

        public Astro(int duraOrbita, int duraRotacion, string nombre)
        {
            this.duarcionRotacion = duraRotacion;
            this.duracionOrbita = duraOrbita;
            this.nombre = nombre;
        }

        protected string Mostrar()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Nombre: " + this.nombre);
            sb.AppendLine("Duracion Orbita: " + this.duracionOrbita);
            sb.AppendLine("Duracion Rotacion: " + this.duarcionRotacion);

            return retorno = Convert.ToString(sb);
        }

        public abstract string Orbita();

        public virtual string Rotar()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Rotando. Tiempo estimado: {0}", this.duarcionRotacion);

            return retorno = Convert.ToString(sb);
        }

        public static explicit operator string(Astro a)
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            if (!a.Equals(null))
            {
                sb.AppendLine(a.nombre);
            }

              return retorno = Convert.ToString(sb);
        }

    }
}
