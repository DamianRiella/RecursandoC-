﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class SistemaSolar
    {
        private List<Astro> planetas;

        public List<Astro> Planetas
        {
            get { return planetas; }
        }

        public SistemaSolar()
        {
            planetas = new List<Astro>();
        }

        public string MostrarInformacionAstros()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            foreach(Planeta item in planetas)
            {
                sb.AppendLine(item.ToString());
            }

            return retorno = Convert.ToString(sb);
        }
    }
}
