﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Planeta : Astro
    {
        private int cantSateites;
        private Tipo tipo;
        private List<Astro> satelites;

        public List<Astro> Satelites
        {
            get{ return satelites; }
        }

        public Planeta(int duarOrbita, int duraRot, string nombre, int cantSatelites, Tipo tipo):this(duarOrbita,duraRot,nombre)
        {
            this.cantSateites = cantSatelites;
            this.tipo = tipo;
        }
        public Planeta(int duarOrbita, int duraRot, string nombre): base(duarOrbita, duraRot, nombre) { }

        public static bool operator +(Astro astro, Planeta planeta)
        {
            bool retorno = false;
            if(astro is Satelite)
            {
                planeta.satelites.Add(astro);
                retorno = true;
            }
                return retorno;
        }

        public static bool operator ==(Planeta planeta, Satelite satelite)
        {
            bool retorno = false;

            foreach(Satelite item in planeta.Satelites)
            {
                if (item.Nombre == satelite.Nombre)
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Planeta planeta, Satelite satelite)
        {
            return !(planeta == satelite);
        }

        public static bool operator ==(Planeta planeta1,Planeta planeta2)
        {
            bool retorno = false;

            if (planeta1.nombre == planeta2.nombre)
            {
                retorno = true;
            }
            return retorno;
        }

        public static bool operator !=(Planeta planeta1, Planeta planeta2)
        {
            return !(planeta1 == planeta2);
        }

        public override string Orbita()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Orbita el planeta: {0}", this.nombre);

            return retorno = Convert.ToString(sb);
        }

        public override string Rotar()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Rota el planeta: {0}", this.nombre);

            return retorno = Convert.ToString(sb);
        }

        public override string ToString()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.Mostrar());
            sb.AppendLine(Convert.ToString(cantSateites));
            sb.AppendLine(Convert.ToString(tipo));

            foreach(Satelite item in satelites)
            {
                sb.AppendLine("Satelite: "+ item.Nombre);
            }

            return retorno = Convert.ToString(sb);
        }

    }
}
