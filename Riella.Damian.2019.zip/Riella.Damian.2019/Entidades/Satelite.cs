﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Satelite: Astro
    {
        public string Nombre
        {
            get { return nombre; }
        }

        public Satelite(int duraOrbita, int duraRotacion,string nombre) : base(duraOrbita, duraRotacion, nombre) { }

        public override string Orbita()
        {
            string retorno;
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Orbita el satelite: {0}", this.nombre);

            return retorno = Convert.ToString(sb);
        }
    }
}
